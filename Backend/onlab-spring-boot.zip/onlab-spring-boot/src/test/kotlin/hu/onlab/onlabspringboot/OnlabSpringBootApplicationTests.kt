package hu.onlab.onlabspringboot

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class OnlabSpringBootApplicationTests {

	@Test
	fun contextLoads() {
	}

}
